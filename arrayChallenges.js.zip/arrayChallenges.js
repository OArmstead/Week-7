// Write a function that is given an array and each time the value is "food" it should 
// console log "yummy". If "food" was not present in the array console log "I'm hungry" once.

function alwaysHungry(array) {
    var WhatYouAte = 0;
    for(var i=0; i<array.length; i++) {
        if(array[i] == "food") {
            console.log("yummy");
            WhatYouAte++;
        }
    }
    if(WhatYouAte == 0) {
        console.log("I'm hungry")
    }
}

// alwaysHungry([3.14, "food", "pie", true, "food"]);
// this should console log "yummy", "yummy"
// alwaysHungry([4, 1, 5, 7, 2]);
// this should console log "I'm hungry"




// High Pass Filter
// Given an array and a value cutoff, 
// return a new array containing only the values larger than cutoff.


function highPass(array, cutoff) {
    var filteredArray = [];
    for(var i = 0; i<array.length; i++){
        if (array[i] > cutoff) {
            filteredArray.push(array[i]) 
            }
        }
        return filteredArray;
    }

var result = highPass([6, 8, 3, 10, -2, 5, 9], 5);
// console.log(result); // we expect back [6, 8, 10, 9]

// Better than average

// Given an array of numbers return a 
// count of how many of the numbers are larger than the average.

function betterThanAverage(array) {
    var sum = 0;
    // calculate the average
    for(var i = 0; i < array.length; i++){
        sum += array[i];
    }
    var average = sum / array.length;
    // console.log(sum);
    // console.log(array.length);
    // console.log(average);
    var count = 0

    for(var i = 0; i < array.length; i++){
        if (array[i] > average){
        count++  
        }
    }
    // count how many values are greater than the average
    return count;
}
var result = betterThanAverage([6, 8, 3, 10, -2, 5, 9]);
// console.log(result); // we expect back 4


// Array Reverse
// Write a function that will reverse the values 
// an array and return them.


function reverse(array) {
    for(var i = 0; i < array.length; i++)
    array.reverse()
    return array;

}

var result = reverse(["a", "b", "c", "d", "e"]);
// console.log(result); // we expect back ["e", "d", "c", "b", "a"]


// Write a function that will return an array of Fibonacci numbers up to a given length n. 
// Fibonacci numbers are calculated by adding the last two values in the sequence together. 
// So if the 4th value is 2 and the 5th value is 3 then the next value in the sequence is 5.

function fibonacciArray(n) {
    // the [0, 1] are the starting values of the array to calculate the rest from
    var fibArray = [0, 1];
    while(fibArray.length < n) {
        var firstNumber = fibArray[fibArray.length-2];
        var secondNumber = fibArray[fibArray.length-1];
        fibArray.push(firstNumber + secondNumber);
    }
    return fibArray;
}

var result = fibonacciArray(10);
// console.log(result); // we expect back [0, 1, 1, 2, 3, 5, 8, 13, 21, 34]


// This was painful but rewarding 